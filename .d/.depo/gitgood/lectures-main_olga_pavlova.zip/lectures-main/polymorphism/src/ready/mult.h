#ifndef MULT_H_LOADED
#define MULT_H_LOADED


double scalar_square(char const *type, ...) __attribute__ \
((format (printf, 1, 2)));

#endif


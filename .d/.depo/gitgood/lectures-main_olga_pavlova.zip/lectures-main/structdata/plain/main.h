#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <termios.h>
#include <unistd.h>

#define PATH_LEN 10
#define MAX_STEP 5
#define STEPS 7

typedef int path[PATH_LEN];

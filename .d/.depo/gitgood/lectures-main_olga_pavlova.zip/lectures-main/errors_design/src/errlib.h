#ifndef ERRLIB_H_LOADED
#define ERRLIB_H_LOADED

static const char * strerror_ru[106] = {
"Неопределённая ошибка",
"Операция не разрешена"
};

#endif

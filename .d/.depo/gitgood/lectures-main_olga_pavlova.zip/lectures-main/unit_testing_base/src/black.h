#ifndef BLACK_H
#define BLACK_H
int black_add(int, int);
int black_subtract(int, int);
int black_multiply(int, int);
int black_divide_allowed(int);
#endif

/**
 * @file cbase.h
 * @brief Универсальный заголовочный файл библиотеки cbase
 */
#ifndef CBASE_H_LOADED
#define CBASE_H_LOADED

//#include "array.h"
#include "counter.h"
//#include "dict.h"
//#include "file.h"
//#include "lim.h"
#include "log.h"
#include "macro.h"
//#include "regmem.h"
//#include "str.h"
#include "iter.h"

#endif

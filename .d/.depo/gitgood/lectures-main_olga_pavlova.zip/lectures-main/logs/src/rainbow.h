/// Радуга • Заголовочный файл
#ifndef RAINBOW_H_LOADED
#define RAINBOW_H_LOADED
#include <stdio.h>
#include <stdlib.h>

#endif
